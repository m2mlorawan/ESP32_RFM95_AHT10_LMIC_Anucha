#include <lmic.h>
#include <hal/hal.h>
#include <SPI.h>
#include <CayenneLPP.h>
#include <AHT10.h>
CayenneLPP lpp(51); // create a buffer of 51 bytes to store the payload
//#define ABP
#define OTA
#define LED_PIN 2
// show debug statements; comment next line to disable debug statements
float slptime = 1;

uint8_t readStatus = 0;
AHT10 myAHT10(AHT10_ADDRESS_0X38);
float temp, pa, hum, alt;
int cnt = 0;

// OTAA
//  The 2 below should be in little endian format (lsb)
static const uint8_t PROGMEM APPEUI[8] = {0x8B, 0x65, 0x00, 0xF0, 0x7E, 0xD5, 0xB3, 0xAA};
static const uint8_t PROGMEM DEVEUI[8] = {0xF1, 0x8F, 0xDA, 0xBB, 0xDD, 0x70, 0x3F, 0xAA};

// This should be in big endian format (msb)
static const uint8_t PROGMEM APPKEY[16] = {0xDA, 0x5A, 0x42, 0xB8, 0x71, 0x50, 0x2E, 0xBA, 0x68, 0x38, 0xC5, 0x28, 0xAA, 0x07, 0xC2, 0x26};

static const uint8_t PROGMEM NWKSKEY[16] = {0xA6, 0xC3, 0x0F, 0xB2, 0x91, 0xDB, 0x55, 0xC5, 0x31, 0x82, 0x53, 0xD4, 0xAA, 0x08, 0x7A, 0x4E};
static const uint8_t PROGMEM APPSKEY[16] = {0x54, 0xBE, 0x2D, 0xE6, 0xB6, 0xB3, 0xF7, 0xC2, 0xD0, 0x33, 0x72, 0xB5, 0xAA, 0x20, 0xD6, 0x20};
static const uint32_t DEVADDR = 0x260115AA;

#ifdef OTA
void os_getArtEui(u1_t *buf)
{
  memcpy_P(buf, APPEUI, 8);
}
void os_getDevEui(u1_t *buf) { memcpy_P(buf, DEVEUI, 8); }
void os_getDevKey(u1_t *buf) { memcpy_P(buf, APPKEY, 16); }
#else
void os_getArtEui(u1_t *buf)
{
}
void os_getDevEui(u1_t *buf) {}
void os_getDevKey(u1_t *buf) {}
#endif

static osjob_t sendjob;
// Schedule TX every this many seconds (might become longer due to duty cycle limitations).
const unsigned TX_INTERVAL = 10;

const lmic_pinmap lmic_pins = {
    .nss = 5,
    .rxtx = LMIC_UNUSED_PIN,
    .rst = LMIC_UNUSED_PIN,
    .dio = {12, 14, 27},
};

void do_send(osjob_t *j)
{
  // Check if there is not a current TX/RX job running
  if (LMIC.opmode & OP_TXRXPEND)
  {
    Serial.println(F("OP_TXRXPEND, not sending"));
  }
  else
  {
    // Prepare upstream data transmission at the next possible time.

    temp = myAHT10.readTemperature();
    hum = myAHT10.readHumidity();

    Serial.print("Temp:");
    Serial.print(temp);
    Serial.println(" C");

    Serial.print("Humd:");
    Serial.print(hum);
    Serial.println(" %");

    lpp.reset(); // clear the buffer
    lpp.addTemperature(2, temp);
    lpp.addRelativeHumidity(3, hum);

    LMIC_setTxData2(1, lpp.getBuffer(), lpp.getSize(), 0);
    Serial.println(F("Packet queued"));
    digitalWrite(LED_PIN,HIGH);
    delay(500);
    digitalWrite(LED_PIN,LOW);
  }
  // Next TX is scheduled after TX_COMPLETE event.
}

void onEvent(ev_t ev)
{
  Serial.print("ev:");
  Serial.println(ev);
  Serial.print(os_getTime());
  Serial.print(": ");
  switch (ev)
  {
  case EV_SCAN_TIMEOUT:
    Serial.println(F("EV_SCAN_TIMEOUT"));
    break;
  case EV_BEACON_FOUND:
    Serial.println(F("EV_BEACON_FOUND"));
    break;
  case EV_BEACON_MISSED:
    Serial.println(F("EV_BEACON_MISSED"));
    break;
  case EV_BEACON_TRACKED:
    Serial.println(F("EV_BEACON_TRACKED"));
    break;
  case EV_JOINING:
    Serial.println(F("EV_JOINING"));
    break;
  case EV_JOINED:
    Serial.println(F("EV_JOINED"));
    // Disable link check validation (automatically enabled
    // during join, but not supported by TTN at this time).
    LMIC_setLinkCheckMode(0);
    break;
  case EV_RFU1:
    Serial.println(F("EV_RFU1"));
    break;
  case EV_JOIN_FAILED:
    Serial.println(F("EV_JOIN_FAILED"));
    break;
  case EV_REJOIN_FAILED:
    Serial.println(F("EV_REJOIN_FAILED"));
    break;
    break;

  case EV_TXCOMPLETE:
    Serial.println();
    Serial.println("=============");
    Serial.print("PACKET#");
    Serial.println(cnt);
    Serial.println("=============");

    cnt = cnt + 1;
    Serial.println(F("EV_TXCOMPLETE (includes waiting for RX windows)"));
    if (LMIC.txrxFlags & TXRX_ACK)
      Serial.println(F("Received ack"));
    if (LMIC.dataLen)
    {
      // data received in rx slot after tx
      Serial.print(F("Received "));
      Serial.print(LMIC.dataLen);
      Serial.print(F(" bytes for downlink: 0x"));
      for (int i = 0; i < LMIC.dataLen; i++)
      {
        if (LMIC.frame[LMIC.dataBeg + i] < 0x10)
        {
          Serial.print(F("0"));
        }
        Serial.print(LMIC.frame[LMIC.dataBeg + i], HEX);
      }
      Serial.println();
    }

    //delay(slptime);
    // Schedule next transmission
    os_setTimedCallback(&sendjob, os_getTime() + sec2osticks(TX_INTERVAL), do_send);
    break;
  case EV_LOST_TSYNC:
    Serial.println(F("EV_LOST_TSYNC"));
    break;
  case EV_RESET:
    Serial.println(F("EV_RESET"));
    break;
  case EV_RXCOMPLETE:
    // data received in ping slot
    Serial.println(F("EV_RXCOMPLETE"));
    break;
  case EV_LINK_DEAD:
    Serial.println(F("EV_LINK_DEAD"));
    break;
  case EV_LINK_ALIVE:
    Serial.println(F("EV_LINK_ALIVE"));
    break;
  //case EV_TXSTART:
  //  Serial.println(F("EV_TXSTART"));
  //  break;
  default:
    Serial.println(F("Unknown event"));
    break;
  }
}

void setup()
{
  Wire.begin();
  delay(2500); // Give time to the ATMega32u4 port to wake up and be recognized by the OS.
  Serial.begin(115200);
  pinMode(LED_PIN,OUTPUT);
  if (!myAHT10.begin())
  {
    Serial.println("No sensor device found, check line or address!");
    while (1)
      ;
  }

  // LMIC init
  os_init();

  // Reset the MAC state. Session and pending data transfers will be discarded.
  LMIC_reset();

#ifdef ABP
// Set static session parameters. Instead of dynamically establishing a session
// by joining the network, precomputed session parameters are be provided.
#ifdef PROGMEM
  // On AVR, these values are stored in flash and only copied to RAM
  // once. Copy them to a temporary buffer here, LMIC_setSession will
  // copy them into a buffer of its own again.
  uint8_t appskey[sizeof(APPSKEY)];
  uint8_t nwkskey[sizeof(NWKSKEY)];

  memcpy_P(appskey, APPSKEY, sizeof(APPSKEY));
  memcpy_P(nwkskey, NWKSKEY, sizeof(NWKSKEY));
  LMIC_setSession(0x1, DEVADDR, nwkskey, appskey);
#else
  // If not running an AVR with PROGMEM, just use the arrays directly
  LMIC_setSession(0x1, DEVADDR, NWKSKEY, APPSKEY);
#endif

#endif

  // Enable link check validation
  LMIC_setLinkCheckMode(0);
  // Enable data rate adaptation
  // LMIC_setAdrMode(1);
  LMIC_setAdrMode(0);
  // Allow small clock errors
  LMIC_setClockError(MAX_CLOCK_ERROR * 10 / 100);

  LMIC.dn2Dr = DR_SF9;

  // Set data rate and transmit power for uplink (note: txpow seems to be ignored by the library)
  //  LMIC_setDrTxpow(DR_SF9, 14);
  LMIC_setDrTxpow(DR_SF7, 14);

  // Start job
  do_send(&sendjob);
  //delay (slptime);
}

void loop()
{
  os_runloop_once();
}
